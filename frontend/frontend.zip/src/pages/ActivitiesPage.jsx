import React from "react";

const ActivitiesPage = () => {
  return <div>ActivitiesPage</div>;
};

export default ActivitiesPage;
