import React from "react";
import DataSection from "../pages/DataSection";
function SchedulePlan() {
  return (
    <div>
      <DataSection tableName="item" />
    </div>
  );
}

export default SchedulePlan;
